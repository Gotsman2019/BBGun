# Unity Camera Shake
Unity 2018.3 project source for completed [Camera Shake Tutorial](https://roystan.net/articles/camera-shake.html) from the site [roystan.net](https://roystan.net/).

![Explosion occurs causing camera shake](https://i.imgur.com/qIGtk20.gif)

Uses Perlin noise to drive the shaking motion. Based on [Math for Game Programmers: Juicing Your Cameras With Math](https://www.youtube.com/watch?v=tu-Qe66AvtY) by [Squirrel Eiserloh](http://www.eiserloh.net/bio/).
